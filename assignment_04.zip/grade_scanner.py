#author: Md Obaydullah Al Numan
#date: 2026-01-02

#grade_scanner.py

all_grades = [
[88, 92, 70], # Student 0 
 [45, 80, 77], # Student 1 (Has a 45!) 
 [99, 100, 95] # Student 2
]


for student_index, grades in enumerate(all_grades):
    for grade in grades:
        if grade < 50:
            print(f"Student[{student_index}] failed a subject")



