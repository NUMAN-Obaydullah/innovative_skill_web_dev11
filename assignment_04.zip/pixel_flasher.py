#author: Md Obaydullah Al Numan
#date: 2026-01-02

#pixel_flasher.py

def activate_row(screen,row_index):
    for i in range(len(screen[row_index])):
        screen[row_index][i] = 1  # Activate pixel
    return screen


monitor = [
[0, 0, 0], 
 [0, 0, 0], 
[0, 0, 0]
]

print(activate_row(monitor, 1))